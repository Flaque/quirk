export interface PulseStamp {
  score: number;
  date: string;
}
